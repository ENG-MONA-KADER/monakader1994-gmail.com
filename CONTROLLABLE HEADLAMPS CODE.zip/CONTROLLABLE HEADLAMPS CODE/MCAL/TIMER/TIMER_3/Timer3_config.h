
#ifndef MCAL_TIMER_TIMER_3_TIMER3_CONFIG_H_
#define MCAL_TIMER_TIMER_3_TIMER3_CONFIG_H_



#define oc_3       fastpwm_3
#define normal_3    0
#define fastpwm_3   1
#define phasepwm_3  2


#endif /* MCAL_TIMER_TIMER_3_TIMER3_CONFIG_H_ */
