/*
 * Timer1_config.h
 *
 *  Created on: ??�/??�/????
 *      Author: vip
 */

#ifndef MCAL_TIMER_TIMER_1_TIMER1_CONFIG_H_
#define MCAL_TIMER_TIMER_1_TIMER1_CONFIG_H_


#define oc_1        normal_1
#define normal_1    0
#define fastpwm_1   1
#define phasepwm_1  2


#endif /* MCAL_TIMER_TIMER_1_TIMER1_CONFIG_H_ */
