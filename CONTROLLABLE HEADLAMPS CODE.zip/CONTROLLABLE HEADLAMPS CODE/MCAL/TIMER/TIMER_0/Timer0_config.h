/*
 * Timer0_config.h
 *
 *  Created on: ??�/??�/????
 *      Author: vip
 */

#ifndef MCAL_TIMER_TIMER_0_TIMER0_CONFIG_H_
#define MCAL_TIMER_TIMER_0_TIMER0_CONFIG_H_


#define oc        normal
#define normal    0
#define fastpwm   1
#define phasepwm  2
#endif /* MCAL_TIMER_TIMER_0_TIMER0_CONFIG_H_ */
